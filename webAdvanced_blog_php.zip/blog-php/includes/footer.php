<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap5.bundle.min.js"></script>
<script src="assets/js/scripts.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
</body>

</html>